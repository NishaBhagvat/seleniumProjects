package com.test.automation.UIActions;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {
	
	public static final Logger log = Logger.getLogger(HomePage.class.getName());
	
	WebDriver driver;

	 
	
	@FindBy(xpath="//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")
	WebElement signIn;
	
	@FindBy(xpath="//*[@id=\"email\"]")
	WebElement loginEmailAddress;
	
	@FindBy(xpath="//*[@id=\"passwd\"]")
	WebElement loginPassword;
	
	@FindBy(id="SubmitLogin")
	WebElement submitButton;
	
	@FindBy(xpath="//*[@id=\"center_column\"]/div[1]/ol/li")
	WebElement failedMessage;
	
	@FindBy(xpath="//*[@id=\"email_create\"]")
	WebElement emailAddressCreateAcc;

	@FindBy(id="SubmitCreate")
	WebElement submitCreateAcc;
	
	@FindBy(id="id_gender1")
	WebElement mr;
	
	@FindBy(id="id_gender2")
	WebElement mrs;
	
	@FindBy(id="customer_firstname")
	WebElement custFirstName;
	
	@FindBy(id="customer_lastname")
	WebElement custLastName;
	
	//@FindBy(xpath="//*[@id=\"email\"]")
	//WebElement emailID;
	
	@FindBy(id="passwd")
	WebElement password;
	
	
	@FindBy(xpath="//*[@id=\"days\"]")
	WebElement days;
	
	@FindBy(xpath="//*[@id=\"months\"]")
	WebElement months;
	
	@FindBy(xpath="//*[@id=\"years\"]")
	WebElement years;
	
	@FindBy(id="optin")
	WebElement checkbox1;
	
	@FindBy(id="firstname")
	WebElement firstname;
	
	@FindBy(id="lastname")
	WebElement lastname;
	
	@FindBy(id="address1")
	WebElement address1;
	
	@FindBy(id="city")
	WebElement city;
	
	@FindBy(id="id_state")
	WebElement State;
	
	@FindBy(id="postcode")
	WebElement postcode;
	
	@FindBy(xpath="//*[@id=\"id_country\"]")
	WebElement country;
	
	@FindBy(id="phone_mobile")
	WebElement phone_mobile;
	
	@FindBy(id="alias")
	WebElement alias;
	
	@FindBy(xpath="//*[@id=\"center_column\"]/p")
	WebElement successMessage;
	
	
	@FindBy(xpath="//*[@id=\"submitAccount\"]/span")
	WebElement registerButton;
	
	
	public  HomePage(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
	}
	
	
	public void loginHomePage(String emailAddress, String password) {
		
		signIn.click();
		log.info("Clicked on sign in and object is "+signIn.toString());
		loginEmailAddress.sendKeys(emailAddress);
		log.info("entered email address "+emailAddress+" and object is"+loginEmailAddress.toString());
		loginPassword.sendKeys(password);
		log.info("entered password "+password+" and object is "+loginPassword.toString());
		submitButton.click();
		log.info("clicked on submit button and object is "+submitButton.toString());
		
	}
	
	public String getInvalidText() {
		
		log.info("authentication failed and error message is "+failedMessage.toString());
		return failedMessage.getText();
		
		
	}
	
	
	
public void createAccount(String emailAddressCreateAcc, String custFirstName, String custLastName, String password, String firstname, String lastname, String address1, String city, String postcode, String phone_mobile, String alias
		) throws InterruptedException {
	
	
	
	signIn.click();
	this.emailAddressCreateAcc.sendKeys(emailAddressCreateAcc);
	log.info("Email address is:- "+emailAddressCreateAcc.toString());
	submitCreateAcc.click();
	log.info("Create account clicked");
	
	mr.click();	
	this.custFirstName.sendKeys(custFirstName);
	log.info("Customer first name is :- "+this.custFirstName.toString());
	this.custLastName.sendKeys(custLastName);
	log.info("Customer last name is :- "+this.custLastName.toString());
	//this.emailID.sendKeys(emailID);
	//log.info("Customer email id:- "+this.emailID.toString());
	this.password.sendKeys(password);
	log.info("Customer password is:- "+this.password.toString());
	Select dateOfBirthDay = new Select(days);
	dateOfBirthDay.selectByIndex(29);

	Select dateOfBirthMonth = new Select(months);
	dateOfBirthMonth.selectByIndex(4);
	Select dateOfBirthYears = new Select(years);
	dateOfBirthYears.selectByIndex(29);
	checkbox1.click();
	this.firstname.sendKeys(firstname);
	log.info("First Name is : "+this.firstname.toString());
	this.lastname.sendKeys(lastname);
	log.info("Last Name is : "+this.lastname.toString());
	this.address1.sendKeys(address1);
	log.info("Address Name is : "+this.address1.toString());
	this.city.sendKeys(city);
	log.info("city Name is : "+this.city.toString());
	
	Select state1=new Select (State);
	state1.selectByValue("31");
	
	this.postcode.sendKeys(postcode);
	
	Select country1 = new Select(country);
	country1.selectByIndex(1);
	
	this.phone_mobile.sendKeys(phone_mobile);
	this.alias.sendKeys(alias);
	
	Thread.sleep(3000);
	
	registerButton.click();
	
	
}

public String getSuccessMessageLogin() {
	
	
	log.info("Success Mesage is : "+successMessage.getText().toString());
	
	return successMessage.getText();
	
	
	
}
	

}
