package com.test.automation.UIActions;

import org.openqa.selenium.WebDriver;

public class VerifyRegistration {
	
	WebDriver driver;
	
	
	
	

}
