package com.test.automation.homepage;

import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;



import com.google.common.io.Files;
import com.test.automation.UIActions.HomePage;
import com.test.automation.testbase.testbase;


public class TC001_VerifyLoginWithInvalidCredentials extends testbase {
	
	
	public static final Logger log = Logger.getLogger(TC001_VerifyLoginWithInvalidCredentials.class.getName());
	HomePage homepage;
	
	@BeforeTest
	public void setUp() {
		
		init();
		
	}
	
	@Test
	public void verifyLoginWithInvalidCredential() {
		
		log.info("======Starting Test=========");
		
		homepage= new HomePage(driver);
		homepage.loginHomePage("nishabhagvat@gmail.com", "password123");
		
		File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	
		 // now copy the  screenshot to desired location using copyFile //method
		//FileUtils.copyFile(src, new File("C:/selenium/error.png"));
		
		
		Assert.assertEquals(homepage.getInvalidText(), "Authentication failed.");
		log.info("==========Finish verifyLoginWithInvalidCredential Test===========");
		
		
	}

	@AfterMethod
	public void endTest() {
		
		driver.close();
		
		
	}
}
