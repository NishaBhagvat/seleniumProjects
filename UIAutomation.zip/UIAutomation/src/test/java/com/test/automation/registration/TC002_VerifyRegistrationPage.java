package com.test.automation.registration;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.test.automation.UIActions.HomePage;
import com.test.automation.testbase.testbase;

public class TC002_VerifyRegistrationPage extends testbase{
	
	HomePage homepage;
	
	@BeforeClass
	public void setUp() {
		
		init();
	}
	
	@Test
	public void createAccount() throws InterruptedException {
		
		log.info("Create Account:");
		homepage = new HomePage(driver);
		homepage.createAccount("nishabhagvat9887@gmail.com", "Nisha", "Bhagvat", "Syntel123$", "Diksha", "Wankhade", "yamunangar", "Pune", "40043", "7447437490", "Alias_Address");
		
		String expected="Welcome to your account. Here you can manage all of your personal information and orders.";
		Assert.assertEquals(homepage.getSuccessMessageLogin(), expected);
		log.info("Account has been created successfully");
		
	}
	
	
	@AfterClass
	public void endTest() {
		
		driver.close();
	}

}
